<?php
class Conexion_users_gestion extends Conexion {

    public function crear(User $usuario){
        try {
            $sql = "INSERT INTO users VALUES (
                null,
                :name,
                :email,
                :password,
                :default,
                :default
            )";

            $stmt = $this->pdo->prepare($sql);

            $stmt->bindParam(':name', $usuario->getName(), PDO::PARAM_STR, 50);
            $stmt->bindParam(':email', $usuario->getEmail(), PDO::PARAM_STR, 50);
            $stmt->bindParam(':password', $usuario->getPassword(), PDO::PARAM_STR, 60);


            
            $stmt->execute();

        } catch (PDOException $e) {
            echo "DETALLES DEL ERROR: <br>";
                    echo "Mensaje Error ".$e->getMessage();
                    echo "<br>";
                    echo "Código de Error".$e->getCode();
                    echo "<br>";
                    echo "Fichero ".$e->getFile();
                    echo "<br>";
                    echo "Línea ".$e->getLine();
        }
    }

    public function actualizar(User $usuario){
        try {
            
            $sql = "UPDATE users SET
                name = :name,
                email = :email,
                password = :password,
                update_at = default
                WHERE id = :id LIMIT 1";

                $stmt = $this->pdo->prepare($sql);

                $stmt->bindParam(':id', $usuario->getId(), PDO::PARAM_INT);
                $stmt->bindParam(':name', $usuario->getName(), PDO::PARAM_STR, 50);
                $stmt->bindParam(':email', $usuario->getEmail(), PDO::PARAM_STR, 50);
                $stmt->bindParam(':password', $usuario->getPassword(), PDO::PARAM_STR, 60);

                
                $stmt->execute();

        } catch (PDOException $e) {
            echo "DETALLES DEL ERROR: <br>";
                    echo "Mensaje Error ".$e->getMessage();
                    echo "<br>";
                    echo "Código de Error".$e->getCode();
                    echo "<br>";
                    echo "Fichero ".$e->getFile();
                    echo "<br>";
                    echo "Línea ".$e->getLine();
        }
    }

    public function eliminar($id){
        try {
            $sql = "DELETE FROM users WHERE $id:id LIMIT 1";

            $stmt = $this->pdo->prepare($sql);

            $stmt->bindParam(':id', $id, PDO::PARAM_INT);

            $stmt->execute();

        } catch (PDOException $e) {
            echo "DETALLES DEL ERROR: <br>";
                    echo "Mensaje Error ".$e->getMessage();
                    echo "<br>";
                    echo "Código de Error".$e->getCode();
                    echo "<br>";
                    echo "Fichero ".$e->getFile();
                    echo "<br>";
                    echo "Línea ".$e->getLine();
        }
    }

    public function getUsuarios(){
        try {

            $sql = "SELECT * FROM users";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            return $stmt;

        } catch (PDOException $e) {
            echo "DETALLES DEL ERROR: <br>";
                    echo "Mensaje Error ".$e->getMessage();
                    echo "<br>";
                    echo "Código de Error".$e->getCode();
                    echo "<br>";
                    echo "Fichero ".$e->getFile();
                    echo "<br>";
                    echo "Línea ".$e->getLine();
        }
    }

    public function getUsuario($id){
        try {

            $sql = "SELECT * FROM users WHERE id = :id LIMIT 1";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch();

        } catch (PDOException $e) {
            echo "DETALLES DEL ERROR: <br>";
                    echo "Mensaje Error ".$e->getMessage();
                    echo "<br>";
                    echo "Código de Error".$e->getCode();
                    echo "<br>";
                    echo "Fichero ".$e->getFile();
                    echo "<br>";
                    echo "Línea ".$e->getLine();
        }
    }

    public function getUsuario_email($email){
        try {
            
            $sql = "SELECT * FROM users WHERE email = :email LIMIT 1";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':email', $email, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch();

        } catch (PDOException $e) {
            echo "DETALLES DEL ERROR: <br>";
                    echo "Mensaje Error ".$e->getMessage();
                    echo "<br>";
                    echo "Código de Error".$e->getCode();
                    echo "<br>";
                    echo "Fichero ".$e->getFile();
                    echo "<br>";
                    echo "Línea ".$e->getLine();
        }
    }


}